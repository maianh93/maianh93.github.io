Cho file giao diện như sau: [index.html](https://techmaster.vn/media/download/source-code/bu0s4ps51co5836g4je0)

Yêu cầu: render ra giao diện giống như hình dựa vào thông tin object student_warning trong phần script

![Ảnh demo](https://techmaster.vn/media/static/9479/bu0s64s51co5836g4jeg)